package com.example.mythread;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    boolean clicked = false;
    boolean reseted = false;
    TextView curVal;
    Handler handler = new Handler();

    int val = 0;
    int sec = 0;
    int min = 0;

    Button reset;
    Button startThread;
    Thread thread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        curVal = findViewById(R.id.CurrentValue);

        startThread = findViewById(R.id.Start);
        reset = findViewById(R.id.reset);

        startThread.setOnClickListener(this);

        reset.setVisibility(View.INVISIBLE);

        reset.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        clicked = !clicked;

        if(val == 0){ reset.setVisibility(View.INVISIBLE); }
        switch(id){
            case R.id.Start:

                if(clicked){
                    reseted = false;
                    Toast.makeText(this,"Start!",Toast.LENGTH_SHORT).show();
                    startThread.setText("Stop");
                    reset.setVisibility(View.VISIBLE);
                } else if(!clicked){
                    Toast.makeText(this,"Pause!",Toast.LENGTH_SHORT).show();
                    startThread.setText("Start");
                }

                thread = new Thread(new Runnable() {

                    @Override
                    public void run() {

                        if(!clicked || reseted){
                            try{
                                wait();
                            }catch (Exception e){}

                            reseted = false;
                        }

                        while(clicked){
                            val+=1;

                            if(val >= 100){
                                val = 0;
                                sec += 1;
                            }

                            if(sec >= 60){
                                sec = 0;
                                min += 1;
                            }

                            handler.post(new Runnable() {
                                public void run() {
                                    curVal.setText(min + " : " + sec +" : " + val);
                                }
                            });

                            try{
                                Thread.sleep(10);
                            } catch (Exception e){}
                        }
                    }
                });

                thread.start();

                break;

            case R.id.reset:

                reseted = true;
                Toast.makeText(this,"Reset!",Toast.LENGTH_SHORT).show();
                startThread.setText("Start");

                val = 0;
                sec = 0;
                min = 0;

                curVal.setText(min + " : " + sec +" : " + val);
                startThread.setText("Start");

                clicked = false;
                reset.setVisibility(View.INVISIBLE);
        }
    }

}
